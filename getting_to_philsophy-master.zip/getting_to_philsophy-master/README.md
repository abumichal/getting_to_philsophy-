Motivation: http://en.wikipedia.org/wiki/Wikipedia:Getting_to_Philosophy  (Gvien a random wiki start page, follow the first link on that page, until you get to the Philsophy page.  Output the path you took, and how many pages you visited.)

Requirements:
pip install beautifulsoup4

For usage instructions, run:
python getting_to_philosophy.py --help
